<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TemporaryTransactionController extends Controller
{
    //
}
