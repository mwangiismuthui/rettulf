$(document).ready(function () {
    //........Toogle dropdown action.......................//
    $(".dropdown-toggle").dropdown();
    // ..................Adding Vehicle brand.................//
   


    //..........changing the status of the make vehicle .................//

  
});
